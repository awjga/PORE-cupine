//---------------------------------------------------------
// Copyright 2015 Ontario Institute for Cancer Research
// Written by Jared Simpson (jared.simpson@oicr.on.ca)
//---------------------------------------------------------
//
// nanopolish_call_variants -- find variants wrt a reference
//
#ifndef NANOPOLISH_CALL_VARIANTS_H
#define NANOPOLISH_CALL_VARIANTS_H

int call_variants_main(int argc, char** argv);

#endif

//---------------------------------------------------------
// Copyright 2017 Ontario Institute for Cancer Research
// Written by Jared Simpson (jared.simpson@oicr.on.ca)
//---------------------------------------------------------
//
#ifndef NANOPOLISH_INDEX_H
#define NANOPOLISH_INDEX_H

#include <string>
#include <vector>

int index_main(int argc, char** argv);

#endif

//---------------------------------------------------------
// Copyright 2016 Ontario Institute for Cancer Research
// Written by Matei David (matei.david@oicr.on.ca)
//---------------------------------------------------------
//
#ifndef NANOPOLISH_EXTRACT_H
#define NANOPOLISH_EXTRACT_H

#include <string>
#include <vector>

#include <fast5.hpp>

int extract_main(int argc, char** argv);

#endif
